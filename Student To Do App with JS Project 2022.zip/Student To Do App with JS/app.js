let stName = document.getElementById("name");
let roll = document.getElementById("roll");
let dept = document.getElementById("dept");
let gpa = document.getElementById("gpa");
let Btn = document.getElementById("Btn");

Btn.addEventListener('click', function(pera){
    pera.preventDefault();
    //console.log(stName.value);
    if(stName.value == '' || roll.value == '' || dept.value == '' || gpa.value == ''){
        alert("Please Fillup All Fields");
    }else{
        //alert("Student Add Success");
        let tr = document.createElement('tr');
        //let td = document.createElement('td');
        let tbody = document.getElementById('tbody');

        // For name value
        let td = document.createElement('td');
        td.innerHTML = stName.value;
        tr.appendChild(td);
        //tbody.appendChild(tr);

        // For roll value
        let td1 = document.createElement('td');
        td1.innerHTML = roll.value;
        tr.appendChild(td1);
        // For dept value
        let td2 = document.createElement('td');
        td2.innerHTML = dept.value;
        tr.appendChild(td2);
        // For gpa value
        let td3 = document.createElement('td');
        td3.innerHTML = gpa.value;
        tr.appendChild(td3);

        tbody.appendChild(tr);
    }

})